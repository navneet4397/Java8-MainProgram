package com.stackroute.java8.fp.gms.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/*
* This class represents the Goldy's GYM staff members' personal details.
* Also it captures awardedCertificates for the trainer for the service rendered in the organization
*/

public class Staff {

    private int id ;
    private String name;
    private String occupation;
    private String address;
    private String program;
    private LocalDate dob;
    private BigDecimal salary;
    private String gender;
    private LocalDate dateOfJoining;
    private String phoneNumber;
    private String email;
    private List<String> awardedCertificates;
    private Map<Integer,String>enrolmentInfo;


    /*Default constructor*/
    public Staff() {

    }


    /*Parameterized  constructor*/
    public Staff(int id, String name, String occupation, String address, String program, LocalDate dob, BigDecimal salary){
        this.id = id;
        this.name = name;
        this.occupation = occupation;
        this.address = address;
        this.program = program;
        this.dob = dob;
        this.salary = salary;
    }


    /*Getters and setters*/
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public LocalDate getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<String> getAwardedCertificates() {
        return awardedCertificates;
    }

    public void setAwardedCertificates(List<String> awardedCertificates) {
        this.awardedCertificates = awardedCertificates;
    }

    public Map<Integer, String> getEnrolmentInfo() {
        return enrolmentInfo;
    }

    public void setEnrolmentInfo(Map<Integer, String> enrolmentInfo) {
        this.enrolmentInfo = enrolmentInfo;
    }


    @Override
    public String toString() {
        return null;
    }
}


