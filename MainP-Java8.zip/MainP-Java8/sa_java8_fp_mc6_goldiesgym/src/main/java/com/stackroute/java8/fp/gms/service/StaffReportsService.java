package com.stackroute.java8.fp.gms.service;

import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Staff;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;


/*
 * Staff reports interface with abstract methods related to the reports of the staff
 */
public interface StaffReportsService {



    List<Staff> findTrainerByAge(int requiredAge);

    Map<String, Integer>  countStaffByProgram();

    List<String> getStaffJoinedInCurrentYear();



}
