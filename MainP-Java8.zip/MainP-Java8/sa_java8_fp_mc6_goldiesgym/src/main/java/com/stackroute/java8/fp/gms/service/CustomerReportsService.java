package com.stackroute.java8.fp.gms.service;

import com.stackroute.java8.fp.gms.model.Customer;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/*
* Customer reports interface with abstract methods related to the reports of the customer
*/

public interface CustomerReportsService {

    Map sortCustomersByAge();

    List<Customer> getCustomersByAge(int age);

    Map getCustomersByPreferredProgram();

}
