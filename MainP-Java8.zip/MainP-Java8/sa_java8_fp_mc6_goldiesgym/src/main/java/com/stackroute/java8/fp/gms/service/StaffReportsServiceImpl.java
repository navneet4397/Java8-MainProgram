package com.stackroute.java8.fp.gms.service;


import com.stackroute.java8.fp.gms.model.Staff;
import com.stackroute.java8.fp.gms.repo.FitnessRepository;
import java.util.*;

public class StaffReportsServiceImpl implements StaffReportsService {


    /*
     * This method finds Staff by  age using streams and Lambda expressions,
     * filter method to filter the map of Staff and collect method to collect the result into a List
     * @param int
     * @return List<Staff>
     */
    static {

        FitnessRepository.createProgram();
        FitnessRepository.createCustomer();
        FitnessRepository.createStaffMemberList();
    }

    @Override
    public List<Staff> findTrainerByAge(int requiredAge){

        return new ArrayList<>();
    }



    /*
     * This method counts Staff by  program using streams and Lambda expressions,forEach
     *  method to iterate over the  map
     *  and collect the result into a Map
     * @param
     * @return Map<String, Integer>
     */
    @Override
    public Map<String, Integer>  countStaffByProgram() {
       return new HashMap<>();
    }

    /*
     * This method gets the  Staff whose year of joining is current year using streams and Lambda expressions,forEach  method to iterate over the the map of Staff by value
     *  and collect the result into a List
     * @param
     * @return List<String>
     */
    @Override
    public List<String> getStaffJoinedInCurrentYear() {

        return new ArrayList<>();
    }

    
}
