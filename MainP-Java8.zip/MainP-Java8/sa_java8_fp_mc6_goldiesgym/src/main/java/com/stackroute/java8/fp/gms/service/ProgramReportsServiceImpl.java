package com.stackroute.java8.fp.gms.service;

import com.stackroute.java8.fp.gms.repo.FitnessRepository;

import java.util.HashMap;
import java.util.Map;

public class ProgramReportsServiceImpl implements ProgramReportsService {

    static{
        FitnessRepository.createCustomer();
        FitnessRepository.createStaffMemberList();
        FitnessRepository.createProgram();

    }
    /*
     * This method counts number of booking per program using streams and Lambda expressions,forEach method is used to iterate the  the map of Programs
     *  and  collect the result into a map
     * @param
     * @return Map<String,Long>
     */

    @Override
    public Map<String,Long> countBookingsByProgram() {

               return new HashMap<>();

    }
}
