package com.stackroute.java8.fp.gms.repo;


import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Program;
import com.stackroute.java8.fp.gms.model.Staff;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Logger;

/*
 * This class represent static data in the form of collection.
 * Any data related to Gym can be created here.
 * It acts as an in-memory db
 */

public class FitnessRepository {


    public static Map<Integer, Staff> staffMembersMap = new HashMap<>();
    public static Map<Integer, Customer> customersMap = new HashMap<>();
    public static Map<Integer, Program> programsMap = new HashMap<>();
    public static Map<String, BigDecimal> yogaPackageCostMap = new HashMap<>();
    public static Map<String, BigDecimal> aerobicsPackageCostMap = new HashMap<>();

    /*
     * Static block the has data for the Staff,Program and Customer,Available time slots and Packages
     */


    public static void createStaffMemberList() {
        Staff firstStaff = new Staff(1, "Andrew", "Trainer", "New York", "Yoga",
                LocalDate.of(1975, 4, 8), BigDecimal.valueOf(30000));
        firstStaff.setGender("Male");
        firstStaff.setDateOfJoining(LocalDate.of(1999, 4, 1));
        firstStaff.setPhoneNumber("+919932485611");
        firstStaff.setEmail("andrew@goldysgym.com");

        Staff secondStaff = new Staff(2, "Hu Chong", "Trainer", "Los Angeles", "Aerobics",
                LocalDate.of(1977, 8, 3), BigDecimal.valueOf(500000.00));
        secondStaff.setGender("Male");
        secondStaff.setDateOfJoining(LocalDate.of(2002, 4, 8));
        secondStaff.setPhoneNumber("+919234567810");
        secondStaff.setEmail("chong@goldysgym.com");

        staffMembersMap.put(1,firstStaff);
        staffMembersMap.put(2,secondStaff);

    }

    public static void createCustomer() {

        Customer firstCustomer = new Customer(1, "Carol", LocalDate.of(1985, 4, 8), "Male", "Software Engineer", "New York");
        firstCustomer.setDob(LocalDate.of(1995, 9, 14));
        firstCustomer.setCustomerType("Regular");
        firstCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        firstCustomer.setPhoneNumber("+1355553535");
        firstCustomer.setEmail("carol@goldiesgym.com");


        Customer secondCustomer = new Customer(2, "Clinton", LocalDate.of(1972, 3, 8), "Male",
                "Agriculturist", "Los Angeles");
        secondCustomer.setDob(LocalDate.of(1992, 2, 14));
        secondCustomer.setCustomerType("Regular");
        secondCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        secondCustomer.setPhoneNumber("+135555432");
        secondCustomer.setEmail("clinton@goldiesgym.com");

        customersMap.put(1, firstCustomer);
        customersMap.put(2, secondCustomer);
    }

    public static void createProgram() {
        String[] yogaSlots = new String[3];
        String[] aerobicSlots = new String[3];


        yogaSlots[0] = "6:00 am to 7:00 am";
        yogaSlots[1] = "7:30 am to 8:30 am";
        yogaSlots[2] = "9:00 am to 10:00 am";
        aerobicSlots[0] = "4:00 pm to 5:00 pm";
        aerobicSlots[1] = "5:00 pm to 6:00 pm";
        aerobicSlots[2] = "6:00 pm to 7:00 pm";

        yogaPackageCostMap.put("3 months Yoga", BigDecimal.valueOf(10000.000));
        aerobicsPackageCostMap.put("3 months Aerobics", BigDecimal.valueOf(20000.000));
        Program yogaProgram = new Program(1, "Yoga", "1 hr");
        Program aerobicsProgram = new Program(2, "Aerobics", "1 hr");
        yogaProgram.setAvailableTimeSlots(Arrays.asList(yogaSlots));
        yogaProgram.setPackageCostMap(yogaPackageCostMap);
        yogaProgram.setCustomerBookingsMap(new HashMap<>());
        yogaProgram.setTimeSlotBookingsMap(new HashMap<>());

        aerobicsProgram.setAvailableTimeSlots(Arrays.asList(aerobicSlots));
        aerobicsProgram.setPackageCostMap(aerobicsPackageCostMap);
        aerobicsProgram.setCustomerBookingsMap(new HashMap<>());
        aerobicsProgram.setTimeSlotBookingsMap(new HashMap<>());

        programsMap.put(1, yogaProgram);
        programsMap.put(2, aerobicsProgram);
    }
}
