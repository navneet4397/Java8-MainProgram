package com.stackroute.java8.fp.gms.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

 /*
 * This class represents the Program  details
 * It also captures type of customer Booking information and time slots booked on a particular day
 * Based the available slots of the program,regular or new customers can book appointment
 * Based on the package opted by the customer,the sessions  will be allocated.
 * Bill wil be generated based on the package opted,gst and discounts for the customer to pay.
  */
public class Program {

    private int programId;
    private String programName;
    private String duration;
    private List<String> availableTimeSlots;
    private Map<String, BigDecimal>packageCostMap;//"3 months Yoga,6:00 am to 7:00 am",10000.000
    private Map<Integer,String> customerBookingsMap;//customerId+programId,"30 days Yoga,6:00 am to 7:00 am"
    private Map<String,Map<String,Integer>>timeSlotBookingsMap;//date["6-7" 10]

     /*Default constructor*/
    public Program() {
    }

    /*Parameterised constructor*/
    public Program(int programId, String programName, String duration){
        this.programId = programId;
        this.programName = programName;
        this.duration = duration;
    }

    /*Getters and setters*/
    public Map<String, BigDecimal> getPackageCostMap() {
        return packageCostMap;
    }

    public void setPackageCostMap(Map<String, BigDecimal> packageCostMap) {
        this.packageCostMap = packageCostMap;
    }

    public int getProgramId() {
        return programId;
    }

    public void setProgramId(int programId) {
        this.programId = programId;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }



    public Map<Integer, String> getCustomerBookingsMap() {
        return customerBookingsMap;
    }


    public void setCustomerBookingsMap(Map<Integer, String> customerBookingsMap) {
        this.customerBookingsMap = customerBookingsMap;
    }


     public Map<String, Map<String, Integer>> getTimeSlotBookingsMap() {
         return timeSlotBookingsMap;
     }

     public void setTimeSlotBookingsMap(Map<String, Map<String, Integer>> timeSlotBookingsMap) {
         this.timeSlotBookingsMap = timeSlotBookingsMap;
     }

     @java.lang.Override
    public java.lang.String toString() {
        return null;
    }

    public List<String> getAvailableTimeSlots() {
        return availableTimeSlots;
    }

    public void setAvailableTimeSlots(List<String> availableTimeSlots) {
        this.availableTimeSlots = availableTimeSlots;
    }
}
