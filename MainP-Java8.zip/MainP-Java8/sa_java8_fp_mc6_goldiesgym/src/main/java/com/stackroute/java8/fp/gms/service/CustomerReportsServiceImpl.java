package com.stackroute.java8.fp.gms.service;


import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.repo.FitnessRepository;
import java.util.*;

import static java.util.stream.Collectors.toMap;

public class CustomerReportsServiceImpl implements CustomerReportsService {

    static {
        FitnessRepository.createCustomer();
        FitnessRepository.createProgram();
        FitnessRepository.createStaffMemberList();
    }

    /*
     * This method sorts customer by  age using streams and Lambda expressions,sorted method to sort
     * the map of customers by value and collect method to collect the result into a map
     * @param
     * @return
     */
    @Override
    public Map<Integer, Customer> sortCustomersByAge() {
        return new HashMap<>();

    }

    /*
     * This method finds customer based on  age greater than the input
     *  using streams and Lambda expressions,
     * filter method to filter the map of customers
     *  and collect method to collect the result into a List
     * @param int
     * @return List<Customer>
     */
    @Override
    public List<Customer> getCustomersByAge(int age) {
        return new ArrayList<>();
    }

    /*
     * This method gets customer by  preferred program using streams and Lambda expressions,
     * forEach method is used to iterate  the map of customers
     *  and collect method to collect the result into a map
     * @param int
     * @return List<Customer>
     */
    @Override
    public Map<String, String> getCustomersByPreferredProgram() {
        return null;
    }


}
