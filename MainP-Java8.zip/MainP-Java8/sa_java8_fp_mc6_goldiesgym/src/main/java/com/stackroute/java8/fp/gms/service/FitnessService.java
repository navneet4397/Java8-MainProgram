package com.stackroute.java8.fp.gms.service;


import com.stackroute.java8.fp.gms.common.FitnessDto;
import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Staff;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface FitnessService {


    /*Transactions*/

    Map<String,Object> enrollCustomer(FitnessDto fitnessDto);

    BigDecimal generateBill(Customer customer);



}
