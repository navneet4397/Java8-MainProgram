package com.stackroute.java8.fp.gms.service;

import com.stackroute.java8.fp.gms.common.FitnessDto;
import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.repo.FitnessRepository;

import java.math.BigDecimal;
import java.util.*;

public class FitnessServiceImpl implements FitnessService {
    static {
        FitnessRepository.createCustomer();
        FitnessRepository.createStaffMemberList();
        FitnessRepository.createProgram();
    }


    /*
     * This method enrolls a customer to a selected program based on the availability of the slots
     * using streams and Lambda expressions,forEach  method to iterate where necessary
     * @param
     * @return
     */
    @Override
    public Map<String, Object> enrollCustomer(FitnessDto fitnessDto) {
        return null;
    }



    /*
     * This method is used to generate bill based on the discount and the gst on the initial amount
     * @param customer
     * @return BigDecimal
     */
    public BigDecimal generateBill(Customer customer) {

        return null;
    }

}


