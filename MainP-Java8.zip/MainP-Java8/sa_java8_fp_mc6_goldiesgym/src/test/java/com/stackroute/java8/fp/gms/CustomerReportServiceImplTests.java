package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.common.FitnessDto;
import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Staff;
import com.stackroute.java8.fp.gms.repo.FitnessRepository;
import com.stackroute.java8.fp.gms.service.CustomerReportsServiceImpl;
import com.stackroute.java8.fp.gms.service.FitnessServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CustomerReportServiceImplTests {

    private CustomerReportsServiceImpl customerReportsService;
    private FitnessServiceImpl fitnessService;

    @BeforeEach
    public void setUp() {
        customerReportsService = new CustomerReportsServiceImpl();
        fitnessService = new FitnessServiceImpl();
    }

    @AfterEach
    public void tearDown() {
        fitnessService =null;
        customerReportsService=null;
    }

    @Test
    public void givenObjectWhenSortCustomersByAgeThenReturnList(){

        Map<Integer,Customer> customersMap =new LinkedHashMap<>();
        Customer firstCustomer = new Customer(1, "Carol", LocalDate.of(1985, 4, 8), "Male", "Software Engineer", "New York");
        firstCustomer.setDob(LocalDate.of(1995, 9, 14));
        firstCustomer.setCustomerType("Regular");
        firstCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        firstCustomer.setPhoneNumber("+1355553535");
        firstCustomer.setEmail("carol@goldiesgym.com");


        Customer secondCustomer = new Customer(2, "Clinton", LocalDate.of(1972, 3, 8), "Male",
                "Agriculturist", "Los Angeles");
        secondCustomer.setDob(LocalDate.of(1992, 2, 14));
        secondCustomer.setCustomerType("Regular");
        secondCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        secondCustomer.setPhoneNumber("+135555432");
        secondCustomer.setEmail("clinton@goldiesgym.com");

        customersMap.put(1, firstCustomer);
        customersMap.put(2, secondCustomer);
        assertEquals(customersMap.size(),customerReportsService.sortCustomersByAge().size());

    }


    @Test
    public void givenObjectWhenGetCustomersByAgeThenReturnList(){

       Customer secondCustomer = new Customer(2, "Clinton", LocalDate.of(1972, 3, 8), "Male",
                "Agriculturist", "Los Angeles");
        secondCustomer.setDob(LocalDate.of(1992, 2, 14));
        secondCustomer.setCustomerType("Regular");
        secondCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        secondCustomer.setPhoneNumber("+135555432");
        secondCustomer.setEmail("clinton@goldiesgym.com");

        List<Customer>expectedList = new ArrayList<>();

        expectedList.add(secondCustomer);
        List<Customer>customersList =  customerReportsService.getCustomersByAge(25);

        assertEquals(expectedList.toString(),customersList.toString());

    }

    @Test
    public void givenObjectWhenGetCustomersByPreferredProgramThenReturnMap(){

        FitnessDto fitnessDto = new FitnessDto(1, 1, 1, LocalDate.now(), "9:00 am to 10:00 am");
        fitnessService.enrollCustomer(fitnessDto);
        FitnessDto fitnessDto2 = new FitnessDto(1, 2, 2, LocalDate.now(), "6:00 am to 7:00 am");
        fitnessService.enrollCustomer(fitnessDto2);

        Map<String,String>expectedMap = new HashMap<>();
        expectedMap.put("Carol","Yoga");

        Map<String,String> customerProgramsMap = customerReportsService.getCustomersByPreferredProgram();

        assertEquals(expectedMap.toString(),customerProgramsMap.toString());
    }

}


