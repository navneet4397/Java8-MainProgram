package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.common.FitnessDto;
import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Program;
import com.stackroute.java8.fp.gms.model.Staff;
import com.stackroute.java8.fp.gms.repo.FitnessRepository;
import com.stackroute.java8.fp.gms.service.FitnessServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class FitnessServiceImplTests {

    private FitnessServiceImpl fitnessServiceImpl;

    @BeforeEach
    public void setUp() {

        fitnessServiceImpl = new FitnessServiceImpl();

    }

    @AfterEach
    public void tearDown() {

        fitnessServiceImpl = null;
    }


    @Test
    public void givenObjectWhenEnrollCustomerThenReturnMap() {

        FitnessDto fitnessDto = new FitnessDto(1, 2, 1, LocalDate.now(), "9:00 am to 10:00 am");

        Map<String, Object> enrollResultMap = fitnessServiceImpl.enrollCustomer(fitnessDto);

        Map<Integer, String> enrolmentMap = new HashMap<>();
        Map<String, Map<String, Integer>> dateTimeSlotMap = new HashMap<>();
        Map<String, Integer> timeSlotMap = new HashMap<>();
        timeSlotMap.put("9:00 am to 10:00 am", 1);
        dateTimeSlotMap.put(LocalDate.now().toString() + ":9:00 am to 10:00 am", timeSlotMap);
        enrolmentMap.put(1, "program : 3 months Yoga booked with Time slot : 9:00 am to 10:00 am");
        assertEquals(enrolmentMap.toString(), ((Customer) enrollResultMap.get("Customer")).getEnrollmentInfo().toString());
        assertEquals(dateTimeSlotMap.toString(), ((Program) enrollResultMap.get("Program")).getTimeSlotBookingsMap().toString());

    }


    @Test
    public void givenObjectWhenGenerateBillThenReturnBigDecimal() {

        FitnessDto fitnessDto = new FitnessDto(1, 1, 2, LocalDate.now(), "4:00 pm to 5:00 pm");

        Map resultMap = fitnessServiceImpl.enrollCustomer(fitnessDto);
        BigDecimal result = fitnessServiceImpl.generateBill((Customer) resultMap.get("Customer"));
        assertEquals(BigDecimal.valueOf(22000.0), (result));

    }

}