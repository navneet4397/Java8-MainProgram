package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.model.Program;
import com.stackroute.java8.fp.gms.model.Staff;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class ProgramTests {



    private Program program;


    @BeforeEach
    public void setUp() {

        program = new Program();
    }

    @AfterEach
    public void tearDown() {
        program = null;
    }

    @Test
    public void givenObjectWhenObjectCreatedThenCheckAllPropertiesAreSet() {


        String [] yogaSlots = new String[3];
        String [] aerobicSlots = new String[3];
        Map<String,BigDecimal> yogaPackageCostMap  = new HashMap<>();
        Map<String,BigDecimal>aerobicsPackageCostMap  = new HashMap<>();

        yogaSlots[0] = "6:00 am to 7:00 am";
        yogaSlots[1] = "7:30 am to 8:30 am";
        yogaSlots[2] = "9:00 am to 10:00 am";
        List<String> slotsList=Arrays.asList(yogaSlots);

        yogaPackageCostMap.put("3 months Yoga",new BigDecimal(10000.000));


        program =new Program(1,"Yoga","1 hr");
        Program aerobicsProgram = new Program(2, "Aerobics", "1 hr");
        program.setAvailableTimeSlots(Arrays.asList(yogaSlots));
        program.setPackageCostMap(yogaPackageCostMap);
        Arrays.asList(yogaSlots);
        assertEquals(1, program.getProgramId());
        assertEquals("Yoga", program.getProgramName());
        assertEquals("1 hr", program.getDuration());
        assertEquals(slotsList, program.getAvailableTimeSlots());
        assertNull(program.getTimeSlotBookingsMap());
        assertNull(program.getCustomerBookingsMap());
    }

    @Test
    public void givenObjectWhenStaffCreatedThenCheckStringRepresentation() {


        String [] yogaSlots = new String[3];
        String [] aerobicSlots = new String[3];
        Map<String,BigDecimal> yogaPackageCostMap  = new HashMap<>();
        Map<String,BigDecimal>aerobicsPackageCostMap  = new HashMap<>();

        yogaSlots[0] = "6:00 am to 7:00 am";
        yogaSlots[1] = "7:30 am to 8:30 am";
        yogaSlots[2] = "9:00 am to 10:00 am";
        List<String> slotsList=Arrays.asList(yogaSlots);

        yogaPackageCostMap.put("3 months Yoga",new BigDecimal(10000.000));

        program = new Program(1,"Yoga","1 hr");
        program.setAvailableTimeSlots(Arrays.asList(yogaSlots));
        program.setPackageCostMap(yogaPackageCostMap);

        String expected = "Program{programId=1, programName='Yoga', duration='1 hr', customerTimeslotMap=null, timeSlotBookingsMap=null}";
        assertEquals(expected.toString(), program.toString());
    }

}
