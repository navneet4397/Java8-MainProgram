package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.common.FitnessDto;
import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.repo.FitnessRepository;
import com.stackroute.java8.fp.gms.service.FitnessServiceImpl;
import com.stackroute.java8.fp.gms.service.ProgramReportsServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProgramReportsServiceImplTests {

    private ProgramReportsServiceImpl programReportService;
    private FitnessServiceImpl fitnessService;


    @BeforeEach
    public void setUp() {

        programReportService = new ProgramReportsServiceImpl();
        fitnessService = new FitnessServiceImpl();
    }

    @AfterEach
    public void tearDown() {
        programReportService = null;
        fitnessService = null;
    }

    @Test
    public void givenObjectWhenCountBookingsByProgramThenReturnMap() {
        FitnessDto fitnessDto = new FitnessDto(1, 1, 1, LocalDate.now(), "7:30 am to 8:30 am");

        fitnessService.enrollCustomer(fitnessDto);
        FitnessDto fitnessDto2 = new FitnessDto(1, 2, 2, LocalDate.now(), "9:00 am to 10:00 am");

        fitnessService.enrollCustomer(fitnessDto2);
        Map<String, Long> staffMap = programReportService.countBookingsByProgram();
        Map<String, Integer> expectedMap = new HashMap<>();
        expectedMap.put("Yoga", 1);
        expectedMap.put("Aerobics", 0);
        assertEquals(expectedMap.toString(), staffMap.toString());
    }
}
