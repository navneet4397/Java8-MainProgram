package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Staff;
import com.stackroute.java8.fp.gms.service.FitnessServiceImpl;
import com.stackroute.java8.fp.gms.service.StaffReportsServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class StaffReportsServiceImplTests {

    private Customer customer;
    private Staff staff;
    private StaffReportsServiceImpl staffReportsService;

    @BeforeEach
    public void setUp() {
        staffReportsService = new StaffReportsServiceImpl();
    }

    @AfterEach
    public void tearDown() {
        staffReportsService = null;
    }


    @Test
    public void givenObjectWhenGetStaffJoinedCurrentYearThenReturnList() {


        List staffList = staffReportsService.getStaffJoinedInCurrentYear();

        assertEquals(0, staffList.size());

    }


    @Test
    public void givenObjectWhenFindTrainerByAgeThenReturnList() {


        List staffList = staffReportsService.findTrainerByAge(25);

        assertEquals(2, staffList.size());

    }

    @Test
    public void givenObjectWhenCountStaffByProgramThenReturnMap() {

        Map<String, Integer> staffMap = staffReportsService.countStaffByProgram();
        Map<String, Integer> expectedMap = new HashMap<>();
        expectedMap.put("Yoga", 1);
        expectedMap.put("Aerobics", 1);
        assertEquals(expectedMap, staffMap);

    }

}