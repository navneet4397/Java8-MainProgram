package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.model.Customer;
import com.stackroute.java8.fp.gms.model.Staff;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;


public class CustomerTests {


    private Customer customer;


    @BeforeEach
    public void setUp() {
        customer = new Customer();
    }

    @AfterEach
    public void tearDown() {
        customer = null;
    }


    @Test
    public void givenObjectWhenObjectCreatedThenCheckAllPropertiesAreSet() {

        Customer firstCustomer = new Customer(1, "Carol", LocalDate.of(1985, 4, 8), "Male", "Software Engineer", "New York");
        firstCustomer.setDob(LocalDate.of(1995, 9, 14));
        firstCustomer.setCustomerType("Regular");
        firstCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        firstCustomer.setPhoneNumber("+1355553535");
        firstCustomer.setEmail("carol@goldiesgym.com");

        assertEquals(1, firstCustomer.getCustomerId());
        assertNull(customer.getEnrollmentInfo());
    }

    @Test
    public void givenObjectWhenAgeComparedThenReturnInteger() {

        Customer firstCustomer = new Customer(1, "Carol", LocalDate.of(1985, 4, 8), "Male", "Software Engineer", "New York");
        firstCustomer.setDob(LocalDate.of(1995, 9, 14));
        firstCustomer.setCustomerType("Regular");
        firstCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        firstCustomer.setPhoneNumber("+1355553535");
        firstCustomer.setEmail("carol@goldiesgym.com");


        Customer secondCustomer = new Customer(2, "Clinton", LocalDate.of(1972, 3, 8), "Male",
                "Agriculturist", "Los Angeles");
        secondCustomer.setDob(LocalDate.of(1992, 2, 14));
        firstCustomer.setCustomerType("Regular");
        firstCustomer.setTotalBillAmount(BigDecimal.valueOf(0.00));
        firstCustomer.setPhoneNumber("+135555432");
        firstCustomer.setEmail("clinton@goldiesgym.com");
        assertEquals(4, secondCustomer.compareTo(firstCustomer));
    }

}