package com.stackroute.java8.fp.gms;

import com.stackroute.java8.fp.gms.model.Staff;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

public class StaffTests {


    private Staff staff;


    @BeforeEach
    public void setUp() {

        staff = new Staff();

    }

    @AfterEach
    public void tearDown() {
        staff = null;
    }

    @Test
    public void givenObjectWhenObjectCreatedThenCheckAllPropertiesAreSet() {

        staff = new Staff(1, "Hu Chong", "Trainer", "Los Angeles", "AEROBICS",
                LocalDate.of(1977, 8, 3), new BigDecimal(500000.00));
        staff.setGender("Male");
        staff.setDateOfJoining(LocalDate.of(1999, 4, 1));
        staff.setPhoneNumber("+919932485611");
        staff.setEmail("chong@goldysgym.com");

        assertEquals(1, staff.getId());
        assertEquals("Hu Chong", staff.getName());
        assertEquals("Trainer", staff.getOccupation());
        assertEquals("Los Angeles", staff.getAddress());
        assertEquals("AEROBICS", staff.getProgram());
        assertEquals(LocalDate.of(1977, 8, 3), staff.getDob());
        assertEquals("Male", staff.getGender());
        assertEquals(new BigDecimal(500000.00), staff.getSalary());
        assertEquals("chong@goldysgym.com", staff.getEmail());
        assertEquals("+919932485611", staff.getPhoneNumber());
        assertEquals(LocalDate.of(1999, 4, 1), staff.getDateOfJoining());
        assertNull(staff.getEnrolmentInfo());
        assertNull(staff.getAwardedCertificates());
    }

    @Test
    public void givenObjectWhenStaffCreatedThenCheckStringRepresentation() {

        staff = new Staff(1, "Hu Chong", "Trainer", "Los Angeles", "AEROBICS", LocalDate.of(1977, 8, 3), new BigDecimal(500000.00));
        //"Male", LocalDate.of(2002, 4, 8), "+919234567810", "chong@goldysgym.com", null, null);
        staff.setGender("Male");
        staff.setDateOfJoining(LocalDate.of(1999, 4, 1));
        staff.setPhoneNumber("+919932485611");
        staff.setEmail("chong@goldysgym.com");

        String expected = "Staff{id=1, name='Hu Chong', occupation='Trainer', address='Los Angeles', " +
                "program='AEROBICS', dob=1977-08-03, salary=500000, gender='Male', dateOfJoining=1999-04-01," +
                " phoneNumber='+919932485611', email='chong@goldysgym.com', awardedCertificates=null, enrolmentInfo=null}";

        assertEquals(expected, staff.toString());
    }


}
