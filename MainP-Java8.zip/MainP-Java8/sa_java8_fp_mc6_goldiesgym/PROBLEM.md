## Problem Statement: Implementing Goldies Gym using functional programming features of Java8 

Goldies Gym is a fitness centre start-up which has just started its operation and managing daily transaction 
manually for Customers, Staff and Gym Program.  

You have been assigned the responsibility to design one automated system which should be able 
to handle daily transaction and generate different reports.

## Proposed Solution
Currently, Goldies Gym operates with 2 programs "Yoga" and "Aerobics" each of 1 hour duration. 
Each program has 3 time slots across the day.In the first phase, Goldies Gym needs a solution 
to automate the current manual operations of the gym. 

High Level Requirements
## Implement the transaction module to:
    • Enroll a customer to a program 
    • Generate bills
## Implement the reporting module to generate reports for:
    • Customers
    • Programs 
    • Staff
    
## Enrollment process
      Gym Administrator recieves a request from the customer for enrolling to a particular program in the gym.
      
       Admin enrolls the customer by using the following info that he has collected from the customer :
     
      trainerId,customerId,ProgramId,enrollment date and desired timeslot.
      
      For the requested time slot,check if it is available in the given time slots.
      
      Condition 1 : If the time slot is not available, set the enrollment status to "No slots available,Please choose another slot".
      Condition 2 : If the time slot is available,find whether the capacity/bookings of that slot for that day is filled .
      Condition 3 : If the booking has not been made,then enroll the customer in the requested slot for that particular program 
                   with given date (enrollFrom) and time(time Slot).
      Condition 4 : If  few time slots are booked on particular days,then check no:of bookings 
                   Condition 4a : If the booking per slot is less than 10,then proceed to enroll the customer in the requested slot for that 					  particular program with given date (enrollFrom) and time(time Slot).Otherwise set enrolment status to 				  "Selected slot is not available for  :'programName'.Please select other slot".
      
      In both the cases, update the customer enrolmentInfo in customer object
      and trainer enrolmentInfo in the Staff object,customer bookings,time slot booking in the program object
      respectively.Finally update the Fitness Repo.
      Make sure to allow only one booking per customer at a time.
      The admin should  be allowed to enroll a customer for a program if and only if  customer's enrolment info 
      is empty otherwise set enrollment status to "Cutomer has already been enrolled for :'programName'.
      Please cancel the same and rebook".

Complete the classes Staff, Customer,Program,FitnessServiceImpl,CustomerReportsServiceImpl,ProgramReportsServiceImpl
 StaffReportsServiceImpl,as per the below requirement

**class Staff**

Define the following properties. properties should be private:        
    
        -id                     : int
        -name                   : String 
        -occupation             : String
	    -address                : String
	    -program                : String
        -dob                    : LocalDate
        -salary                 : BigDecimal
	    -gender	                : String
       	-dateOfJoining	        : LocalDate
      	-phoneNumber            : String
     	-email 	                : String
    	-awardedCertificates    : List<String> 
     	-enrolmentInfo          : Map<Integer,Integer>
- Override the toString method 

- Define parameterized constructor to  all the properties. 

- Define Getters and Setters for all the properties

**Class Customer implements Comparable**

Define the following properties.Properties should be private:
    
    -customerId	        : int
    -name		        : int
    -dob		        : String
    -gender	  	        : char
    -occupation         : String
    -address	        : String
    -enrollmentDate     : String
    -enrollmentInfo     : Map<Integer, String> 
    -enrollmentStatus   : String
    -customerType	    : String
    -paymentStatus	    : String
    -fitnessProfile	    : Map<String,Integer>
    -phoneNumber	    : String
    -email		        : String
- implement compareTo method to compare customer by age using DateUtil class after implementing as mentioned below.
- Override the toString method
  

**Class Program**

Define the following properties. properties should be private:
    
    -programId	              : int
    -programName	          : String
    -duration	              : String
    -cost      	              : BigDecimal 
    -customerBookingsMap      : Map<Integer,String>   
    -timeSlotBookingsMap      : Map<String,Map<String,Integer>>
    -availableTimeSlots       : List<String>   
- Override the toString method       
- Define Getters and Setters for the properties

**class FitnessRepository**

	Has static data for Staff,Customer,Program,ProgramTimeSlots.
	
**class FitnessDto**

     This class represents an object to transfer data between the modules.The values are set in  order to pass as
     a parameter to the method and in the called method the values are obtained using the getters.
     
**class FitnessServiceImpl**
	
     +enrollCustomer(int trainerId,Customer customer,LocalDate enrollFrom,String timeSlot):Map<String,Object>
            Should enroll the customer based on the program choosen and available time slot
            Follow the enrolment process explained above.
            Update the customer,Program and staff objects accordingly and return map with all 3 objects
     +generateBill(Customer customer):BigDecimal
            must return total bill amount after generating the bill for a particular customer
            based on  the program chosen,gst,and discounts it customers is above 40 years of age
		
**class StaffReportsServiceImpl**

     +getStaffJoinedInCurrentYear():map
            must return the names of all employees who have joined in current year
     +countStaffByProgram():map
            must return all the staff grouped by the program
      +findTrainerByAge(int age):list
            must return the list of trainers who are older than given years of age in the organization 	
            
**class CustomerReportsServiceImpl**
	
       +getCustomersByPreferredProgram():Map
            Must return a map of customers grouped by preferredProgram
       +sortCustomersByAge():List
            must return the  list of customers sorted by age 
       +getCustomersByAge(int age)
            must return the Lis of customers who are older than given years of age
        
**class ProgramReportsServiceImpl**
 
       +countBookingsByProgram():Map
            Must return the map grouped by program 

**DateUtil must be implemented using TDD for the following methods**

    +calculateAge(LocalDate dob):int
		must return an integer after calculating the age of a person 
	+calculateYearOfService(LocalDate dateOfJoining):int
		must return an integer after calculating the years/months of service from dateOfJoining till date.
	+checkNullEmpty(LocalDate inputDate):boolean
			must return a boolean based on the input passed.

## Instructions
- Do not change the provided class/method names unless instructed
- Ensure your code compiles without any errors/warning/deprecations 
- Follow best practices while coding

