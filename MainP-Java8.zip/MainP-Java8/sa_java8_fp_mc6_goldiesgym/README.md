## Seed code - Boilerplate

### Instructions
Refer the problem.md file for problem description. 

#### Please follow these steps to complete the assignment

1. **FORK** this repository in your Gitlab account

2. **CLONE** the forked repository, containing the boilerplate in your local machine
     
3. Navigate to  sa_java8_fp_mc6_goldiesgym folder

    `cd sa_java8_fp_mc6_goldiesgym`

4. Check the status of your repository
     
     `git status`

5. Complete the solution as per the instructions given in PROBLEM.md and the boilerplate code

6. Use the following command to update the index using the current content found in the working tree, to prepare the content staged for the next commit.

     `git add .`
 
7. Commit and Push the project to git

     `git commit -a -m "Initial commit | or place your comments according to your need"`

     `git push -u origin master`

8. Check on the git repo online, if the files have been pushed

9. Submit your solution on Hobbes


### Important instructions for Participants
> - We expect you to write the assignment on your own by following through the guidelines, learning plan, and the practice exercises
> - The code must not be plagiarized, the mentors will randomly pick the submissions and may ask you to explain the solution
> - The code must be properly indented, code structure maintained as per the boilerplate and properly commented
> - Follow through the problem statement shared with you

### MENTORS TO BEGIN REVIEW YOUR WORK ONLY AFTER ->
> - You add the respective Mentor as a Reporter/Master into your Assignment Repository
> - You have checked your Assignment on the Automated Evaluation Tool - Hobbes (Check for necessary steps in your Boilerplate - README.md file. ) and got the required score - Check with your mentor about the Score you must achieve before it is accepted for Manual Submission.
> - Intimate your Mentor on Slack and/or Send an Email to learner.support@stackroute.in - with your Git URL - Once you done working and is ready for final submission.

### Further Instructions on Release
- Test your code against the tes cases given.

## Implement TDD approach for one of the class mentioned in Problem.md


## Problem Statement

Goldies Gym has started business in 2016 as a specialized fitness center. 
It started operations from a 200 sqm floor area in the suburbs of Boston.
All the operations in the gym were performed manually.The gym administrator had to face a lot of issues in
terms of managing customers,Staff and programs.The transactions became more cumbersome as the  customers grew in number.


## Proposed Solution
In the first phase, Goldies Gym needs a solution that eliminates the hurdles of manual operations in the gym. 
Goldies gym operates with 2 programs "Yoga" and "Aerobics" each of 1 hour duration. Each program has 3 time slots across the day.

## High Level Requirements

### Implement the transaction module to:

  - Enroll a customer to a program
  - Generate bills
  
### Implement the reports module to generate reports for:
   - Customers
   - Programs 
   - Staff
### Implement a date management utility with TDD approach. The test coverage must be over 90%.

## Tech Stack

- Java 11
- JUnit 5

## Flow of Modules
- Build the date management utility with TDD approach
- Build the transaction module
- Build the reports module
- Test the transaction and reports modules



 

